import 'react-native-gesture-handler';
import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import {
  View, Text, Button, StyleSheet, FlatList, TouchableOpacity, TextInput, Alert
} from 'react-native';

const Stack = createNativeStackNavigator();
const Drawer = createDrawerNavigator();

// 💻 Tela de Login com campos de usuário e senha
function LoginScreen({ navigation }) {
  const [user, setUser] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    if (user && password) {
      navigation.replace('Drawer');
    } else {
      Alert.alert('Erro', 'Digite usuário e senha');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login</Text>
      <TextInput
        placeholder="Usuário"
        value={user}
        onChangeText={setUser}
        style={styles.input}
      />
      <TextInput
        placeholder="Senha"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        style={styles.input}
      />
      <Button title="Entrar" onPress={handleLogin} />
    </View>
  );
}

// 🔐 Tela do Cofre de Senhas com botões "Adicionar" e "Apagar" embaixo do título
function VaultScreen({ passwords }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Cofre de Senhas</Text>
      <View style={styles.buttonRow}>
        <Button title="Adicionar" onPress={() => {}} />
        <View style={{ width: 10 }} />
        <Button title="Apagar" onPress={() => {}} />
      </View>
      <FlatList
        data={passwords}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.item}>
            <Text selectable>{item}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

// 🛠️ Função para gerar senhas
function generatePassword(length = 12) {
  const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+';
  let password = '';
  for (let i = 0; i < length; i++) {
    password += charset.charAt(Math.floor(Math.random() * charset.length));
  }
  return password;
}

// ⚙️ Tela de Gerador
function GeneratorScreen({ route }) {
  const [password, setPassword] = useState('');

  const handleGenerate = () => {
    const newPass = generatePassword();
    setPassword(newPass);
    route.params?.addPassword(newPass);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Gerador de Senhas</Text>
      <Text selectable style={styles.password}>{password}</Text>
      <Button title="Gerar Senha" onPress={handleGenerate} />
    </View>
  );
}

// 🧭 Menu lateral
function DrawerNavigator({ passwords, addPassword }) {
  return (
    <Drawer.Navigator>
      <Drawer.Screen name="Gerador de Senhas">
        {(props) => <GeneratorScreen {...props} addPassword={addPassword} />}
      </Drawer.Screen>
      <Drawer.Screen name="Cofre de Senhas">
        {(props) => <VaultScreen {...props} passwords={passwords} />}
      </Drawer.Screen>
    </Drawer.Navigator>
  );
}

// 🚀 App Principal
export default function App() {
  const [passwords, setPasswords] = useState([]);

  const addPassword = (pass) => {
    setPasswords([pass, ...passwords]);
  };

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login" screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Drawer">
          {() => <DrawerNavigator passwords={passwords} addPassword={addPassword} />}
        </Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// 🎨 Estilos
const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', padding: 20, justifyContent: 'flex-start' },
  title: { fontSize: 24, marginVertical: 20 },
  password: { fontSize: 20, marginBottom: 20, color: 'green' },
  item: {
    backgroundColor: '#eee',
    padding: 10,
    marginVertical: 4,
    borderRadius: 5,
    width: '100%',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    width: '100%',
    marginBottom: 10,
    borderRadius: 5,
  },
  buttonRow: {
    flexDirection: 'row',
    marginBottom: 20,
    justifyContent: 'center',
  }
});
